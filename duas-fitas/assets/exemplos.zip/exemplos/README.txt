===========================
### palavra-inversa.jff ###
L� uma palavra e escreve a sua inversa.
Alfabeto = a, b, c, t, e
EXEMPLO
Entrada
	Fita 1 = abacate
	Fita 2 = 
Sa�da
	Fita 1 = abacate
	Fita 2 = etacab

===========================
###### subtracao.jff ######
Faz subtra��o de uma opera��o com uns (1).
Alfabeto = 1, -
EXEMPLO
Entrada
	Fita 1 = 111-11
	Fita 2 = 
Sa�da
	Fita 1 = 111-11
	Fita 2 = 1

===========================
#### troca-B-por-Y.jff ####
Quando, na mesma posi��o, a Fita 1 possuir
um B e a Fita 2 possuir um Y, eles ser�o
trocados de fita.
Alfabeto = a, b, x, y
EXEMPLO
Entrada
	Fita 1 = aabaabbba
	Fita 2 = xyxxyyyxx
Sa�da
	Fita 1 = aabaayyba
	Fita 2 = xyxxybbxx